package edu.utsa.cs3443.fasttrack_projectdemo_javafx;

import edu.utsa.cs3443.fasttrack_projectdemo_javafx.model.Manager;
import edu.utsa.cs3443.fasttrack_projectdemo_javafx.model.Vehicle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Super important, Kept creating a new static currReminderID instead of importing it. Important to remember.
 */
import static edu.utsa.cs3443.fasttrack_projectdemo_javafx.VehicleDetailsController.currVehicleID;

public class AddVehicleController {
        Stage mainStage;
        @FXML
        private Label FastTrackLabel;
        @FXML
        private TextField insertMake;
        @FXML
        private TextField insertModel;
        @FXML
        private TextField insertColor;
        @FXML
        private TextField insertMileage;
        @FXML
        private TextField insertMPG;
        @FXML
        private TextField insertAMPG;
        @FXML
        private Label submitLabel;

        public void backClick(){
            changeScreen("layouts/vehicles-list.fxml");
        }

        public void changeScreen(String fxmlPath){
            try {
                mainStage = (Stage) FastTrackLabel.getScene().getWindow();
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlPath));
                Scene mainMenuScene = new Scene(fxmlLoader.load());
                mainStage.setScene(mainMenuScene);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void homeClick(){
            changeScreen("layouts/main-screen.fxml");
        }

        public void createClick(){
            String make = insertMake.getText().trim();
            String model = insertModel.getText().trim();
            String color = insertColor.getText().trim();

            if (make.isEmpty() || model.isEmpty() || color.isEmpty() || insertMileage.getText().trim().isEmpty() || insertMPG.getText().trim().isEmpty() || insertAMPG.getText().trim().isEmpty()){
                submitLabel.setText("ERROR: Please fill in every field.");
                return;
            }

            try{
                int mileage = Integer.parseInt(insertMileage.getText().trim());
                double MPG = Double.parseDouble(insertMPG.getText().trim());
                double avgMPG = Double.parseDouble(insertAMPG.getText().trim());

                if (mileage < 0 || MPG < 0 || avgMPG < 0){
                    submitLabel.setText("ERROR: Numbers cannot be negative.");
                    return;
                }
                Manager a = new Manager();
                a.addVehicle(make, model, color, mileage, MPG, avgMPG);
                changeScreen("layouts/vehicles-list.fxml");
            }
            catch (NumberFormatException e){
                submitLabel.setText("ERROR: Mileage and MPG must be valid numbers.");
            }
        }
    }
