package edu.utsa.cs3443.fasttrack_projectdemo_javafx;

import edu.utsa.cs3443.fasttrack_projectdemo_javafx.model.Manager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Super important, Kept creating a new static currReminderID instead of importing it. Important to remember.
 */

public class AddReminderController {
    Stage mainStage;
    @FXML
    private Label FastTrackLabel;
    @FXML
    private TextField ReminderNameInsert;
    @FXML
    private Label errorLabel;
    @FXML
    private TextField DueDateInsert;
    @FXML
    private TextField LocationInsert;

    public void backClick(){
        changeScreen("layouts/vehicle-details.fxml");
    }
    public void homeClick(){
        changeScreen("layouts/main-screen.fxml");
    }
    /**
     * 1. Give error message if any field is blank, or if any field contains invalid input.
     * 2. Call the appropriate create method in Manager, which randomly generates an ID and saves the object to file
     * 3. Upon successful creation, return user to previous screen
     */
    public void createClick(){
        String reminderName = ReminderNameInsert.getText().trim();
        String dueDate = DueDateInsert.getText().trim();
        String location = LocationInsert.getText().trim();

        if (reminderName.isEmpty() || dueDate.isEmpty() || location.isEmpty()){
            errorLabel.setText("ERROR: Fields cannot be left blank.");
        }
        else{
            Manager a = new Manager();
            a.addReminder(reminderName, dueDate, location, VehicleDetailsController.currVehicleID);
            changeScreen("layouts/vehicle-details.fxml");
        }
    }
    public void changeScreen(String fxmlPath){
        try {
            mainStage = (Stage) FastTrackLabel.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlPath));
            Scene mainMenuScene = new Scene(fxmlLoader.load());
            mainStage.setScene(mainMenuScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

